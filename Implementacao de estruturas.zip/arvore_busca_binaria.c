#include<stdio.h>
#include<stdlib.h>
typedef struct content{
    char nome[20];
    int telefone;
    int idade;
}content;

typedef struct node{
	content c;
	struct node *esq, *dir;
}node;
//apontador = um ponteiro pra nodo
//registro é o meu conteudo

node** inicia(node **ponteiro);
void add(content inserir, node **ponteiro);
void search(content encontra, node *ponteiro);
void previous(node *q , node **r);
void retira(content remover, node **ponteiro);
void imprimir_pre_ordem(node *ponteiro);
void imprimir_central(node *ponteiro);
void imprimir_pos_ordem(node *ponteiro);
void limpa(node *p);
int main(int argc, char const *argv[])
{
	node **p;
	p = inicia(p);
	content aux ;
	int choice;
	//por algum motivo desconhecido ele não incializa p se eu usar a função como void, então fiz inicia devolver o ponteiro
	//alocado pra ele mesmo. Ai funciona.
    while(1){
    	printf("\n0 - Adiciona \n");
    	printf("1 - Procura por nome\n");
    	printf("2 - Remove por nome\n");
    	printf("3 - Imprime Central\n");
    	printf("4 - Imprime Pré-Ordem\n");
    	printf("5 - Imprime Pós-Ordem\n");
    	printf("6 - Sair\n");
    	scanf("%d",&choice);
    	switch(choice){
    		case 0:
	    		printf("Nome: \n");
	    		scanf("%s",aux.nome);
	    		printf("Idade: \n");
	    		scanf("%d",&aux.idade);
	    		printf("Telefone: \n");
	    		scanf("%d",&aux.telefone);
	    		add(aux,p);
	    		break;
	    	case 1:
	    		printf("Procurar por nome: \n");
	    		scanf("%s",aux.nome);
	    		search(aux,*p);
	    		break;
	    	case 2:
	    		printf("Remover por nome: \n");
	    		scanf("%s",aux.nome);
	    		retira(aux,p);
	    		break;
	    	case 3:
	    		imprimir_central(*p);
	    		break;
	    	case 4:
	    		imprimir_pre_ordem(*p);
	    		break;
	    	case 5:
	    		imprimir_pos_ordem(*p);
	    		break;
	    	case 6:
	    		limpa(*p);
	    		free(p);
	    		printf("Memória limpa\n");
	    		return 0;
	    	default:
	    		printf("Opção inválida.\n");
    	}


    }
}

/*void search(int *inserir, node *ponteiro){
	if(ponteiro==NULL){//casos base, ele chega no fundo, ou encontra o número
		printf("Número não encontrado na árvore.\n");
		return;
	}
	else if(ponteiro->i == *inserir){
		printf("Número encontrado na árvore\n");
		return;
	}
	else if(*inserir<ponteiro->i){//se o numero que eu quero inserir é menor que o que eu tenho, vou pra esquerda
		search(inserir,ponteiro->esq);
		return;
	}
	else if(*inserir>ponteiro->i){//se o numero que eu quero inserir é maior que o que eu tenho, vou pra direita
		search(inserir,ponteiro->dir);
		return;
	}

}*/
void search(content encontra, node *ponteiro){
	if(ponteiro==NULL){//casos base, ele chega no fundo, ou encontra o número
		printf("%s não encontrado na árvore.\n",encontra.nome);
		return;
	}
	else if(strcmp(ponteiro->c.nome,encontra.nome)==0){
		printf("%s encontrado na árvore\n",encontra.nome);
		return;
	}
	else if(strcmp(ponteiro->c.nome,encontra.nome)>0){//se o nome o que eu quero inserir é "menor alfabeticamente" que o que eu tenho, vou pra esquerda
		search(encontra,ponteiro->esq);
		return;
	}
	else if(strcmp(ponteiro->c.nome,encontra.nome)<0){//se o numero que eu quero inserir é "maior alfabeticamente" que o que eu tenho, vou pra direita
		search(encontra,ponteiro->dir);
		return;
	}
	//return;//funciona com o return aqui, ou sem o return também pq a função é void.

}

void add(content inserir, node **ponteiro){//pra inserir, tenho um ponteiro pra ponteiro
	//só vou inserir se eu chegar no final da árvore
	if(*ponteiro == NULL){//cheguei no final da árvore, crio o nodo e coloco ele aqui.
		*ponteiro = (node*) malloc(sizeof(node));//ponteiro aponta pra outro ponteiro
		(*ponteiro)->c = inserir;
		(*ponteiro)->esq = NULL;
		(*ponteiro)->dir = NULL;
		//printf("adicionei %d \n",inserir );
		return;
	}
	else if(strcmp(inserir.nome,(*ponteiro)->c.nome)<0){
		add(inserir,&(*ponteiro)->esq);
		return;
	}
	else if(strcmp(inserir.nome,(*ponteiro)->c.nome)>0){
		add(inserir,&(*ponteiro)->dir);
		return;
	}
	else{
		printf("ERRO, pessoa já existe na árvore.\n");
	}
	//return;//também funciona só com o return aqui, ou até sem no return já que a fução é void.
}

node** inicia(node **ponteiro){
	ponteiro = (node**) malloc (sizeof(node*));
	*ponteiro = NULL;
	return ponteiro;
}

void retira(content remover, node **ponteiro){
	node *aux;
	//condições relacionadas com o lado que vou procurar
	if(*ponteiro == NULL){
		printf("Erro,pessoa não existe na árvore\n");
		return;
	}
	else if((strcmp(remover.nome,(*ponteiro)->c.nome)<0)){
		retira(remover,&(*ponteiro)->esq);
		return;
	}
	else if(strcmp(remover.nome,(*ponteiro)->c.nome)>0){
		retira(remover,&(*ponteiro)->dir);
		return;
	}

	//condições relacionadas com o lado direito do ponteiro
	if((*ponteiro)->dir ==NULL){
		aux = *ponteiro;
		*ponteiro = (*ponteiro)->esq;
		free(aux);
		return;
	}

	//condições relacionadas com o lado esquerdo do ponteiro.
	if((*ponteiro)->esq!=NULL){
		previous(*ponteiro,&(*ponteiro)->esq);
		return;
	}
	else if((*ponteiro)->esq!=NULL){
		aux = *ponteiro;
		*ponteiro = (*ponteiro)->dir;
		free(aux);
	}
}

void previous(node *q , node **r){//essa eu não entendi como funciona.
	node *aux;
	if((*r)->dir!=NULL){
		previous(q,&(*r)->dir);
		return;
	}
	q->c = (*r)->c;
	aux = *r;
	*r = (*r)->esq;
	free(aux);
}

void imprimir_pre_ordem(node *ponteiro){
	if(ponteiro!=NULL){
		printf("---------------------\n");
		printf("Nome: %s\n",ponteiro->c.nome);
		printf("Idade: %d\n",ponteiro->c.idade);
		printf("Telefone: %d\n",ponteiro->c.telefone);
        printf("---------------------");
		imprimir_pre_ordem(ponteiro->esq);
		imprimir_pre_ordem(ponteiro->dir);
	}
}

void imprimir_central(node *ponteiro){
	if(ponteiro!=NULL){
		imprimir_central(ponteiro->esq);
		printf("---------------------\n");
		printf("Nome: %s\n",ponteiro->c.nome);
		printf("Idade: %d\",ponteiro->c.idade);
		printf("Telefone: %d\n",ponteiro->c.telefone);
        printf("---------------------");
		imprimir_central(ponteiro->dir);
	}
}

void imprimir_pos_ordem(node *ponteiro){
	if(ponteiro!=NULL){
		imprimir_pos_ordem(ponteiro->esq);
		imprimir_pos_ordem(ponteiro->dir);
		printf("---------------------\n");
		printf("Nome: %s\n",ponteiro->c.nome);
		printf("Idade: %d\n",ponteiro->c.idade);
		printf("Telefone: %d\n",ponteiro->c.telefone);
        printf("---------------------");
	}

}

void limpa(node *p){
	if(p!=NULL){
		limpa(p->esq);
		limpa(p->dir);
		free(p);
	}
}

