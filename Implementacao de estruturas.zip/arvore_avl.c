#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node{
	int i;
	struct node *dir,*esq;
}node;
//apontador e dicionario é um ponteiro pra ponteiro de node

int altura(node *ponteiro);
int fator_balanceamento(node *ponteiro);
void rs_esquerda(node **p);
void rs_direita(node **p);
int balanceamento(node **p);
int balanca_esquerda(node **p);
int balanca_direita(node **p);
int insere(node **p, int inserir);
int avl(node *p);
void imprimir_pre_ordem(node *ponteiro);
int main(int argc, char const *argv[])
{
	node **p;
	p = (node**) malloc (sizeof(node*));
	*p = NULL;
	int c, aux;
	for(c=0;c<5;c++){
		printf("Numero: \n");
		scanf("%d",&aux);
		insere(p,aux);


		//printf("É avl? %d\n",avl(*p) );
	}
	imprimir_pre_ordem(*p);
	printf("Altura da árvore %d\n",altura(*p));
	return 0;
}

int fator_balanceamento(node *ponteiro){
	//Fator de balanceamento de um nó é a diferença entre a altura
	//das sub-árvores da direita e da esquerda.
	if(ponteiro==NULL){
		return 0;
	}
	return(altura(ponteiro->esq) - altura(ponteiro->dir));
}

int altura(node *ponteiro){
	int altura_esquerda=1,altura_direita=1;
	if(ponteiro==NULL || (ponteiro->dir==NULL && ponteiro->esq==NULL)){
		return 0;
	}

	altura_esquerda += altura(ponteiro->esq);
	altura_direita += altura(ponteiro->dir);

	if(altura_esquerda>altura_direita){
		return altura_esquerda;
	}
	else{
		return altura_direita;
	}

}

void rs_esquerda(node **p){//rotação simples pra esquerda
	node *aux;
	aux = (*p)->dir;
	(*p)->dir = (*p)->esq;
	(*p)->esq = (*p);
	(*p) = aux;
}
//as rotações são iguais, mas com os ponteiros invertidos
void rs_direita(node **p){//rotação simples pra direita
	node *aux;
	aux = (*p)->esq;
	(*p)->esq = (*p)->dir;
	(*p)->dir = (*p);
	(*p) = aux;
}
int balanca_esquerda(node **p){
	int fb_esq = fator_balanceamento((*p)->esq);
	if(fb_esq > 0){
		rs_direita(p);
		return 1;
	}
	else if (fb_esq<0){
		//rotação dupla direita
		rs_esquerda(&((*p)->esq));
		rs_direita(p);
		return 1;
	}
	return 0;
}
int balanca_direita(node **p){
	int fb_dir = fator_balanceamento((*p)->dir);
	if(fb_dir < 0){
		rs_esquerda(p);
		return 1;
	}
	else if (fb_dir > 0){
		//rotação dupla esquerda
		rs_direita(&((*p)->dir));
		rs_esquerda(p);
		return 1;
	}
	return 0;
}
int balanceamento(node **p){
	int fb = fator_balanceamento(*p);
	if(fb > 1){
		return balanca_esquerda(p);
	}
	else if(fb <1 ){
		return balanca_direita(p);
	}
	return 0;
}

int insere(node **p, int inserir){
	if(*p==NULL){
		*p = (node*) malloc (sizeof(node));
		(*p)->i = inserir;
		(*p)->esq = NULL;
		(*p)->dir = NULL;
		printf("inseri %d\n",inserir);
		return 1;
	}
	else if(inserir <(*p)->i){
		if(insere(&(*p)->esq,inserir)){
			if(balanceamento(p)){
				return 0;
			}
			else{

				return 1;
			}
		}
		return 0;
	}
	else if (inserir >(*p)->i){
		if(insere(&(*p)->dir,inserir)){
			if(balanceamento(p)){
				return 0;
			}
			else{
				return 1;
			}
		}
		else{
			return 0;
		}
	}
	else{
		return 0;//valor já presente
	}
}

int avl(node *p){
	int fb;
	if(p==NULL){
		return 1;
	}
	if(!avl(p->esq)){
		return 0;
	}
	if(!avl(p->dir)){
		return 0;
	}

	fb = fator_balanceamento(p);
	if((fb>1)||(fb<-1)){
		return 0;
	}

	return 1;
}

void imprimir_pre_ordem(node *ponteiro){
	if(ponteiro!=NULL){
		printf(" %d\n",ponteiro->i);
		imprimir_pre_ordem(ponteiro->esq);
		imprimir_pre_ordem(ponteiro->dir);
	}
}

