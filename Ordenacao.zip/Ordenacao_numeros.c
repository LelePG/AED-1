#include<stdio.h>
void ordena_insertion(int *v);
void ordena_selection(int *v);
void ordena_bubble(int *v);
void imprime(int *v);
void copia(int *v, int *aux);

int n =5;
int main(){
	int v[n], aux[n];
	for(int c=0;c<n;c++){
		printf("Digite o numero: \n");
		scanf("%d",&v[c]);
	}
	copia(v,aux);
	printf("\nINSERTION: \n");
	ordena_insertion(aux);
	imprime(aux);

	copia(v,aux);
	printf("\nSELECTION: \n");
	ordena_selection(aux);
	imprime(aux);

	copia(v,aux);
	printf("\nBUBBLE: \n");
	ordena_bubble(aux);
	imprime(aux);

	return 0;
}

void ordena_insertion(int *v){
	int c,c2,temp;
	for(c=0;c<n;c++){
		temp = v[c];//Pega o elemento c
		c2 = c-1;
		while(c2>=0 && v[c2]>temp){//e compara pra tras ate chegar no inicio ou achar um menor
			v[c2+1] = v[c2];//se for maior, puxa
			c2--;
		}
	v[c2+1]=temp;//coloca temp na posicao de trocar
	}
}
void ordena_selection(int *v){
	int c,c2,temp,troca;
	for(c=0;c<n;c++){
		troca = c;//salva a posicao do "menor numero"
		for(c2=c;c2<n;c2++){
			if(v[c2] < v[troca]){//se v[c2] eh menor, salva c2 como posicao pra troca
				troca = c2;
			}
		}
	temp = v[troca];//faz a troca do menor elemento com o elemento em v[c]
	v[troca] = v[c];
	v[c] = temp;
	}
}
void ordena_bubble(int *v){
	int c,c2,temp;
	for(c=0;c<n;c++){//pega o primeiro elemento
		for(c2=0;c2<n-1;c2++){//e compara com todos os outros
			if(v[c2]>v[c2+1]){//se v[c2] mais v[c2+1] troca os dois
				temp = v[c2];
				v[c2] = v[c2+1];
				v[c2+1] =temp;
			}
		}
	}
}

void imprime(int *v){
	for(int c=0;c<5;c++){
		printf("%d ",v[c]);
	}
}

void copia(int *v, int*aux){
	for(int c=0;c<n;c++){
		aux[c] = v[c];
	}

}