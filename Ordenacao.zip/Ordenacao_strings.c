#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define n 5

void ordena_insertion(char** s);
void ordena_selection(char** s);
void ordena_bubble(char** s);
void copia(char** s,char** s2);
void imprime(char** s);
void ordena_quick(char** s, int inicio, int fim);
void ordena_merge(char** s, int inicio, int fim);
void merging(char** s, int inicio, int meio, int fim);



int main() {
int c;
char **nomes, **aux;
nomes = (char**) malloc(n*sizeof(char*));
for(c=0;c<n;c++){
	nomes[c] = (char*) malloc(15*sizeof(char));
}
aux = (char**) malloc(n*sizeof(char*));
for(c=0;c<n;c++){
	aux[c] = (char*) malloc(15*sizeof(char));
}
//preencche matriz
for(c=0;c<n;c++){
	printf("Digite:\n");
	scanf("%[^\n]",nomes[c]);
	getchar();
}
	copia(nomes,aux);
	printf("\nINSERTION: \n");
	ordena_insertion(aux);
	imprime(aux);

	copia(nomes,aux);
	printf("\nSELECTION: \n");
	ordena_selection(aux);
	imprime(aux);

	copia(nomes,aux);
	printf("\nBUBBLE: \n");
	ordena_bubble(aux);
	imprime(aux);

	copia(nomes,aux);
	printf("\nQUICK: \n");
	ordena_quick(aux,0,n-1);
	imprime(aux);

	copia(nomes,aux);
	printf("\nMERGE: \n");
	ordena_merge(aux,0,n-1);
	imprime(aux);
return 0;

}

void ordena_insertion(char** s){
	int c,c2;
	char temp[15];
	for(c=0;c<n;c++){
		strcpy(temp,s[c]);
		c2 = c -1;
		while(c2>=0 && strcmp(s[c2],temp)>0){
			strcpy(s[c2+1],s[c2]);
			c2--;
		}
		strcpy(s[c2+1],temp);
	}
}
void ordena_selection(char** s){
	int c,c2,troca;
	char aux[15];
	for(c=0;c<n-1;c++){
		troca = c;
		for(c2=c;c2<n;c2++){
			if(strcmp(s[c2],s[troca])<0){
				troca = c2;
			}
		}
		strcpy(aux,s[c]);
		strcpy(s[c],s[troca]);
		strcpy(s[troca],aux);
	}
}
void ordena_bubble(char** s){
int c,c2;
char aux[15];
	for(c=0;c<n-1;c++){
		for(c2=0;c2<n-1;c2++){
			if(strcmp(s[c2],s[c2+1])>0){
			//se for maior que zero nomes[c2] eh maior
				strcpy(aux,s[c2+1]);
				strcpy(s[c2+1],s[c2]);
				strcpy(s[c2],aux);
			}
		}
	}
}
void copia(char** s,char** s2){
	for(int c=0;c<n;c++){
	strcpy(s2[c],s[c]);
	}
}
void imprime(char** s){
	printf("NOMES: \n");
	for(int c=0;c<n;c++){
		printf("%s\n",s[c]);
	}
}

void ordena_quick(char** s, int inicio, int fim){
	int i,f,meio;
	char aux[15];
	i = inicio;
	f = fim;
	meio = (inicio+fim)/2;
	do{
		while(strcmp(s[i],s[meio])<0){//Essas duas sao as unicas comparaçoes de conteudo do quick, as outras sao comparaçoes de indices
		i++;
		}
		while(strcmp(s[f],s[meio])>0){
        f--;
		}
		if(i<=f){
			strcpy(aux,s[i]);
			strcpy(s[i],s[f]);
			strcpy(s[f],aux);
			i++;
			f--;
		}
    }while(i<=f);

	if(inicio<=f){
		ordena_quick(s,inicio,f);
	}
	if(i<fim){
		ordena_quick(s,i,fim);
	}

}

void ordena_merge(char** s, int inicio, int fim){
	int meio;
	if(inicio<fim){
		meio = (inicio +fim)/2;
		ordena_merge(s,inicio,meio);
		ordena_merge(s,meio+1,fim);
		merging(s,inicio,meio,fim);
	}
}
void merging(char** s , int inicio, int meio, int fim){
	//declarando vetor auxiliar
	char **aux = (char**) malloc (n*sizeof(char*));
	for(int c=0;c<n;c++){
		aux[c] = (char*) malloc(15*sizeof(char));
	}
	int cont_1,cont_2,pos;
	cont_1 = inicio;
	cont_2 = meio +1;
	pos = 0;
	while(cont_1<=meio && cont_2<=fim){//enquanto tiver elementos nas duas linhas
		if(strcmp(s[cont_1],s[cont_2])<0){
			strcpy(aux[pos],s[cont_1]);
			cont_1++;
		}
		else{
			strcpy(aux[pos],s[cont_2]);
			cont_2++;
		}
		pos++;
	}
	while(cont_1<=meio){//se ficar coisa na primeira lista
		strcpy(aux[pos],s[cont_1]);
		pos++;
		cont_1++;
	}
	while(cont_2<=fim){
		strcpy(aux[pos],s[cont_2]);
		pos++;
		cont_2++;
	}
	for(int c=0;c<pos;c++){
		strcpy(s[c+inicio],aux[c]);
	}

}

