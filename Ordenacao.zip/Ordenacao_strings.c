

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void ordena_insertion(char** s);
void ordena_selection(char** s);
void ordena_bubble(char** s);
void copia(char** s,char** s2);
void imprime(char** s);

int n =5;
int main() {
int c;
char **nomes, **aux;

nomes = (char**) malloc(n*sizeof(char*));
for(c=0;c<n;c++){
nomes[c] = (char*) malloc(15*sizeof(char));
}
aux = (char**) malloc(n*sizeof(char*));
for(c=0;c<n;c++){
aux[c] = (char*) malloc(15*sizeof(char));
}
//preencche matriz
for(c=0;c<n;c++){
	printf("Digite:\n");
	scanf("%[^\n]",nomes[c]);
	getchar();
}
	copia(nomes,aux);
	printf("\nINSERTION: \n");
	ordena_insertion(aux);
	imprime(aux);

	copia(nomes,aux);
	printf("\nSELECTION: \n");
	ordena_selection(aux);
	imprime(aux);

	copia(nomes,aux);
	printf("\nBUBBLE: \n");
	ordena_bubble(aux);
	imprime(aux);

return 0;

}

void ordena_insertion(char** s){
	int c,c2;
	char temp[15];
	for(c=0;c<n;c++){
		strcpy(temp,s[c]);
		c2 = c -1;
		while(c2>=0 && strcmp(s[c2],temp)>0){
			strcpy(s[c2+1],s[c2]);
			c2--;
		}
		strcpy(s[c2+1],temp);
	}
}
void ordena_selection(char** s){
	int c,c2,troca;
	char aux[15];
	for(c=0;c<n-1;c++){
		troca = c;
		for(c2=c;c2<n;c2++){
			if(strcmp(s[c2],s[troca])<0){
				troca = c2;
			}
		}
		strcpy(aux,s[c]);
		strcpy(s[c],s[troca]);
		strcpy(s[troca],aux);
	}
}
void ordena_bubble(char** s){
int c,c2;
char aux[15];
	for(c=0;c<n-1;c++){
		for(c2=0;c2<n-1;c2++){
			if(strcmp(s[c2],s[c2+1])>0){
			//se for maior que zero s[c2] eh maior
				strcpy(aux,s[c2+1]);
				strcpy(s[c2+1],s[c2]);
				strcpy(s[c2],aux);
			}
		}
	}
}
void copia(char** s,char** s2){
	for(int c=0;c<n;c++){
	strcpy(s2[c],s[c]);
	}
}
void imprime(char** s){
	printf("NOMES: \n");
	for(int c=0;c<n;c++){
		printf("%s\n",s[c]);
	}
}
