// Nao se preocupem com isso
#define RED     "\x1b[31m"
#define GREEN   "\x1b[32m"
#define RESET   "\x1b[0m"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define uteis
#define OFFSET 97
#define ALFABETO 26
#define true 1
#define false 0
#define bool int
#define INVALIDO -1
#define DEFAULT "Pais desconhecido\0"

// Estruturas de dados
struct Celula {
    char * pais;
    char * frase;
};

struct Dicionario {
    struct Celula letras[ALFABETO];
};

typedef struct Celula Celula;
typedef struct Dicionario Dicionario;

// Pesquisar : retorna true se a frase esta no dicionario, false caso contrario
int pesquisar(Dicionario * dicionario, char * frase) {
    for (int i = 0; i < ALFABETO; i++) {
        if (dicionario->letras[i].frase != NULL) {
            if (strcmp(dicionario->letras[i].frase, frase) == 0) {
                return i;
            }
        }
    }
    return INVALIDO;
}

// Inserir : insere par pais - frase no dicionario caso a primeira letra do pais esteja livre e retorna true, false caso nao insira
bool inserir(Dicionario * dicionario, char * pais, char * frase) {
    char l;//contador char
    for(l ='a';(l-OFFSET)<ALFABETO;l++){
        if((l==pais[0] || l-32 ==pais[0]) && dicionario->letras[l-OFFSET].pais==NULL){//so adiciona se for null e a posicao for maiuscula ou minuscula
        dicionario->letras[l-OFFSET].pais = (char*) malloc(sizeof(char)*strlen(pais));
        verifica(dicionario->letras[l-OFFSET].pais);
        strcpy(dicionario->letras[l-OFFSET].pais,pais);
        dicionario->letras[l-OFFSET].frase = (char*) malloc(sizeof(char)*strlen(frase));
        verifica(dicionario->letras[l-OFFSET].frase);
        strcpy(dicionario->letras[l-OFFSET].frase,frase);
        return true;
        }
    }

    return false;
}

void imprime(Dicionario * dicionario) {//CREI ESSA FUNÇÃO pra verificar se está adicionando todos os elementos direito.
    int contador = 0;
    for(contador =0;contador<ALFABETO;contador++){
        if(dicionario->letras[contador].pais!=NULL){//não imprime as posições nulas
            printf("País - %s  Frase - %s\n",dicionario->letras[contador].pais,dicionario->letras[contador].frase);
        }
    }
}

// Identificar : retorna a a traducao de "Feliz Natal!" no pais passado como parametro caso esteja no dicionario, retorna frase DEFAULT caso contrario
char * identificar(Dicionario * dicionario, char * frase) {
   int c;
   for(c=0;c<ALFABETO;c++){
        if(dicionario->letras[c].frase!=NULL && strcmp(dicionario->letras[c].frase, frase)==0){
        return dicionario->letras[c].pais;
        }
   }

    return DEFAULT;
}

void verifica(void* p){//ADICIONEI verifica se a memoria foi alocada corretamente
    if(p==NULL){
        printf("ERRO!\n");
        exit(1);
    }
}
// Inicializa dicionario
Dicionario * initDicionario() {
    Dicionario * d = (Dicionario *) malloc(sizeof(Dicionario));
    verifica(d);
    for (int i = 0; i < ALFABETO; i++) {
        d->letras[i].pais = NULL;
    }

    printf("Inserindo brasil\n");
    inserir(d, "brasil\0", "Feliz Natal!\0");

    printf("Inserindo alemanha\n");
    inserir(d, "alemanha", "Frohliche Weihnachten!\0");

    printf("Inserindo coreia\n");
    inserir(d, "coreia", "Chuk Sung Tan!\0");

    printf("Inserindo grecia\n");
    inserir(d, "grecia", "Kala Christougena!\0");

    printf("Inserindo estados-unidos\n");
    inserir(d, "estados-unidos", "Merry Christmas!\0");

    printf("Inserindo suecia\n");
    inserir(d, "suecia", "God Jul!");

    printf("Inserindo turquia\n");
    inserir(d, "turquia", "Mutlu Noeller\0");

    printf("Inserindo mexico\n");
    inserir(d, "mexico", "Feliz Navidad!\0");

    printf("Inserindo italia\n");
    inserir(d, "italia", "Buon Natale!\0");

    printf("Inserindo japao\n");
    inserir(d, "japao", "Merii Kurisumasu!\0");

    printf("Inserindo irlanda\n");//INSERI teste pra verificar se ignora as letras repetidas
    inserir(d, "irlanda", "--");

    printf("Inserindo belarus\n");//INSERI teste pra verificar se ignora as letras repetidas
    inserir(d, "belarus", "--");

    printf("Inserindo Kiev\n");//INSERI teste pra verificar as letras maiusculas
    inserir(d, "Kiev", "--");

    return d;
}

void limpa_memoria(Dicionario*d){
    for (int c = 0; c < ALFABETO; c++) {
        if (d->letras[c].pais != NULL) {
            free(d->letras[c].pais);
            free(d->letras[c].frase);
        }
    }
    free(d);
}

int main() {
    printf("---Inicializacao---\n");
    Dicionario * d = initDicionario();
   // char * resultado;//RETIREI a variável resultado pq ela é desnecessária
    imprime(d);//CRIEI A FUNÇÃO pra verificar a inicialização do dicionário
    printf("\n---Testes de Validacao---\n");
    printf("1. Pesquisa por traducao existente");
    if (pesquisar(d, "Feliz Natal!\0") != INVALIDO) {
        printf(GREEN " PASS!\n" RESET);
    }
    else {
        printf(RED " FAIL.\n" RESET);
    }

    printf("2. Pesquisa por traducao nao existente");
    if (pesquisar(d, "Nollaig Shona Dhuit!\0") == INVALIDO) {
        printf(GREEN " PASS!\n" RESET);
    }
    else {
        printf(RED " FAIL.\n" RESET);
    }

    printf("3. Saudacao valida");
    if (strcmp(identificar(d, "Merii Kurisumasu!\0"), "japao") == 0) {
        printf(GREEN " PASS!\n" RESET);
    }
    else {
        printf(RED " FAIL.\n" RESET);
    }

    printf("4. Saudacao invalida");
    if (strcmp(identificar(d, "Nollaig Shona Dhuit!\0"), DEFAULT) == 0) {
        printf(GREEN " PASS!\n" RESET);
    }
    else {
        printf(RED " FAIL.\n" RESET);
    }
    limpa_memoria(d);//CRIEI
    return 0;
}
